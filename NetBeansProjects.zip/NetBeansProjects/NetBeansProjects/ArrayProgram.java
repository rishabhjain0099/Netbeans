class ArrayProgram
{
	public static void main(String []args)
	{
		int data[]=new int[10];
		java.util.Scanner sc=new java.util.Scanner(System.in);
		System.out.println("Enter 10 Values");
		for(int i=0;i<10;i++){
			System.out.print("value "+(i+1)+"=");
			data[i]=sc.nextInt();
		}
		System.out.print("Enter Additional Value to do perform Task::");
		int additionalValue=sc.nextInt();
		System.out.println();

		int equal=0,max=0,min=0;
		for(int temp:data){
			if(additionalValue==temp)equal++;
			else if(additionalValue<temp)max++;
			else {min++;}
		}

		System.out.println("Total Same Values Are="+equal);
		System.out.println("Total Max Values Are="+max);
		System.out.println("Total Min Values Are="+min);

	}
}