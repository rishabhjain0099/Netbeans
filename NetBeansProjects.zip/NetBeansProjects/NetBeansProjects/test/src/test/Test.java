// A Java program to demonstrate differences between array
// and ArrayLisestt
package test;
import java.util.ArrayList;
class Test
{
    public static void main(String args[])
    {
       // allowed
        int[] array = new int[3];
 
        // allowed, however, need to be intialized
        Test[] array1 = new Test[3];
 
        // not allowed (Uncommenting below line causes
        // compiler error)
        // ArrayList<char> arrL = new ArrayList<char>();
 
        // Allowed
        ArrayList<Integer> arrL1 = new ArrayList<>();
        ArrayList<String> arrL2 = new ArrayList<>();
        ArrayList<Object> arrL3 = new ArrayList<>();
    }
}