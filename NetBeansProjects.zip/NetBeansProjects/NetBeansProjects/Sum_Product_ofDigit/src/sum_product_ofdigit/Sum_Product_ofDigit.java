/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sum_product_ofdigit;

/**
 *
 * @author my
 */
class Sum_Product_ofDigit{
	public static void main(String args[]){
		int num = Integer.parseInt(args[0]); //taking value as command line
		
			int temp = num,result=0;
		//Logic for sum of digit
		while(temp>0){
			result = result + temp;
			temp--;
		}
		System.out.println("Sum of Digit for "+num+" is : "+result);
		//Logic for product of digit
		temp = num;
		result = 1;
		while(temp > 0){
			result = result * temp;
			temp--;
		}
		System.out.println("Product of Digit for "+num+" is : "+result);
	}
}