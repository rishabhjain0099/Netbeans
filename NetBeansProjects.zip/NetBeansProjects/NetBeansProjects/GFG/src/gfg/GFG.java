/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gfg;

/**
 *
 * @author my
 */
import java.io.*;
 
class GFG {
    public static void main(String[] args)
    {
        int[] a; // valid declaration
        int b[]; // valid declaration
        int[] c; // valid declaration
     
    }
}
