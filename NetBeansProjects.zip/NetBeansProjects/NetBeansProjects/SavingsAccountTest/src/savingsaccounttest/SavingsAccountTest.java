/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package savingsaccounttest;

/**
 *
 * @author my
 */
import java.util.Scanner; 

public class SavingsAccountTest
{
    public static void main(String[] args)
    {
        double startBalance; 
        double annualInterestRate; 
        int months; 
        double depositAmount; 
        double withdrawAmount; 

        //Using a Scanner so we can easily pull in different data types

        Scanner input = new Scanner(System.in); 
        //Prompt user for starting balance 
        System.out.print("Enter starting balance: $"); 
        startBalance = input.nextDouble(); 

        //Prompt user for annual interest rate
        System.out.print("Enter annual interest rate: "); 
        annualInterestRate = input.nextDouble(); 

        //Prompt user for number of months
        System.out.print("Enter the number of months: ");
        months = input.nextInt(); 

       SavingsAccountTest sa = new SavingsAccountTest(startBalance,annualInterestRate); 

        for (int i = 1; i <= months; i++)
        {
            // Prompt user for deposit amount
            System.out.print("Enter amount to deposit for the month " + i + ":$"); 
            depositAmount = input.nextDouble(); 

            sa.setDeposit(depositAmount); 

            // Prompt user for amount to withdraw
            System.out.print("Enter amount to withdraw for the month " + i + ":$"); 
            withdrawAmount = input.nextDouble(); 

            sa.setWithdraw(withdrawAmount); 

            sa.accrueMonthlyInterest();

        }

        displayData(sa); 
    }

    /**
     * Displays the details of the savings account
     */
    public static void displayData(SavingsAccount sa)
    {
        double balance = Math.round(sa.getBalance() * 100.0) / 100.0; 
        double totalInterest = Math.round(sa.getTotalInterest() * 100.0) / 100.0; 
        System.out.println(); 
        System.out.println("The ending balance is: $" + balance); 
        System.out.println("Total amount of deposits: $" + sa.getTotalDeposits());
        System.out.println("Total amount of withdraws: $" + sa.getTotalWithdraws());
        System.out.println("Total interest earned: $" + totalInterest);
    }
}

