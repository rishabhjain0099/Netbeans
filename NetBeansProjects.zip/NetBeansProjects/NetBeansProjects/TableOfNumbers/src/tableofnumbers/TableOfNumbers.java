/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableofnumbers;

/**
 *
 * @author my
 */
class TableOfNumbers
{

	public static void main(String []args)
	{
		String data="";
		for(int i=5;i<16;i++)
		{
			for(int j=1;j<=10;j++)
			{
				long temp=i*j;
				data=data+(i+"*"+j+"="+(temp)+"  squ="+(temp*temp)+"  cube="+(temp*temp*temp)+"\n");
			}
			javax.swing.JOptionPane.showMessageDialog(null,data);
			data="";
		}
        }
}
		
	